import java.util.Scanner;

public class Main {
    public static void main(String[]args) {
        //declares
        Scanner scanner = new Scanner(System.in);
        String[] vehicle = {"Car", "Motor Bike"}; // to display the top vehicles
        String[][] city = {{"Cape Town    "},{"Johannesburg"},{"Port Elizabeth"}}; //to display on the side
        int[][] accidents = new int[3][2];
        int totalAccidents =0;

        System.out.println("Enter the number of car accidents for Cape Town: ");
        accidents[0][0] = scanner.nextInt();
        System.out.println("Enter the number of motor bike accidents for Cape Town: ");
        accidents[0][1] = scanner.nextInt();

        System.out.println("Enter the number of car accidents for Johannesburg: ");
        accidents[1][0] = scanner.nextInt();
        System.out.println("Enter the number of motor bike accidents for Johannesburg: ");
        accidents[1][1] = scanner.nextInt();

        System.out.println("Enter the number of car accidents for Port Elizabeth: ");
        accidents[2][0] = scanner.nextInt();
        System.out.println("Enter the number of motor bike accidents for Port Elizabeth: ");
        accidents[2][1] = scanner.nextInt();;

        System.out.print("-----------------------------------------"+"\n"+"Road Accidents Reports"+"\n"+"-----------------------------------------"+"\n");

        System.out.print("\t\t\t\t\t"+vehicle[0]+ "\t\t\t"+vehicle[1]);


        for (int i=0; i<3;i++){// runs throw one dimesnional array cities
            System.out.print("\n"+city[i][0]+"\t\t");
            for (int b=0; b< 2;b++) {
                System.out.print(accidents[i][b] + "\t\t\t");// two Dimensional array showing }}

            }}
        System.out.print("\n" + "-----------------------------------------" + "\n" + "ROAD ACCIDENTS TOTALS FOR EACH CITY" + "\n" + "-----------------------------------------");
                for (int j=0; j< 3;j++){
                    System.out.print("\n"+city[j][0]+"\t\t");

                    for (int c=0; c< 2;c++){
                        totalAccidents= (accidents[j][c] + accidents[j][c]); }//calculates total accidents
                    System.out.print(totalAccidents); }
            }

    }
