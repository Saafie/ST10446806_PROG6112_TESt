import java.util.Scanner;

public abstract class RoadAccidents {
    //declare
    private String vehicleType;
    private String city;
    private int totalNoOfAccidents;

    public RoadAccidents(String vehicleType,String City, int totalNoOfAccidents){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the accident vehicle type: ");
        this.vehicleType = scanner.next();//enter vehicle type

        System.out.print("Enter the city for the vehicle: ");
        this.city = scanner.next();// enter city

        System.out.print("Enter the total Car accidents for the " + city + ": ");
        this.totalNoOfAccidents = Integer.parseInt(scanner.next());// total accidents

    }

    public String getVehicleType(){//get method
        return vehicleType;
    }

    public int getTotalNoOfAccidents(){//getmethod
        return totalNoOfAccidents;
    }

    public String getCity(){//get method
        return city;
    }

}

interface iRoadAccidents{
    String getAccidentVehicleType();
    String getCity();
    int getAccidentTotal();
}

class RoadAccidentReports extends RoadAccidents {

    public RoadAccidentReports(String vehicleType, String city, int totalNoOfAccidents) {
        super(vehicleType,city, totalNoOfAccidents);}

    public void RoadAccidents(String vehicleType, int propertyPrices){
        //displays values
        System.out.print("\n"+"VEHICLE ACCIDENT REPORT"+"\n"+"**********************"+"\n"+"VEHICLE TYPE: " + getVehicleType()+ "\n" + "CITY: " + getCity() + "\n"+"Accidents Total: "+ getTotalNoOfAccidents()+"\n"+"**********************");



    }}

class RunApplication{
    public static void main(String[]args){
        String names = "";
        String city ="";
        int price =0;

        //instantiates object
        RoadAccidentReports vehicle = new RoadAccidentReports(names,city, price);
        vehicle.RoadAccidents(names,price); }}